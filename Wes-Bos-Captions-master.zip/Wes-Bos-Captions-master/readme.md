# Captions

This is a Github Repo containing all the captions for my video courses. Edits are very welcome as the transcribers who create these aren't 100% perfect. 

`RFB` → [React For Beginners](https://ReactForBeginners.com)

`ES6` → [ES6 for Everyone](https://ES6.io)

`JS3` → [JavaScript30](https://JavaScript30.com)

`NODE` → [Learn Node](https://LearnNode.com)

`GRID` → [CSS Grid.io](https://CSSGrid.io)


## Translations
Translations are welcome - just append the language code to the file name. Example: 

* English: `04 - Temporal Dead Zone.vtt`
* Portuguese (Brazil): `04 - Temporal Dead Zone-pt-BR.vtt`



